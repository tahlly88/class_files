# Group 4 Pacman
### Goals
The goals of this group was to 
1. Enable the user to select between one or two players.
2. Enable the user to select the number of ghosts
3. Enable the player to change the difficulty by changing the speed at which the ghosts and Pacman move.

The Options menu uses the abstract window toolkit, this ensure that a wide variety of JDK environments should be supported without any issues. I specifically used OpenJDK 11.0.13.

After importing the code into your Eclipse, the game is launched by running PacManWithUI.java as a Java Application.

The group was organized as

##### Michael Gates : Team lead / Lead front-end developer / tester
##### Zachary Green : Lead back-end developer / tester
##### Matthew Robertson : Tester / Lead technical writer
##### Semir Pita : Tester / Technical writer
##### James Sanders : Tester / Technical writer / proofreader
##### Rawlin (Kinsley) Cook : Presentation / Technical writer / Tester

#### Johnathan La Voy :  Tester