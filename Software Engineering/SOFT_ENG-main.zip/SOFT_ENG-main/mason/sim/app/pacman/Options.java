package sim.app.pacman;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JRadioButton;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ButtonGroup;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.AbstractAction;
import javax.swing.Action;


//This is the options menu that starts up when PacManWithUI.java is ran.
public class Options extends JFrame {

	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	private final ButtonGroup buttonGroup_2 = new ButtonGroup();
	private final Action action = new SwingAction();

	/**
	 * Launch the application.
	 */
	public static void showFrame() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Options frame = new Options();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	//Show the window.
	public static void showWindow() {
		showFrame();
	}

	/**
	 * Create the frame.
	 */
	public Options() {
		setForeground(Color.WHITE);
		setBackground(Color.BLACK);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 399, 463);
		contentPane = new JPanel();
		contentPane.setForeground(Color.WHITE);
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnStartGame = new JButton("Start Game");
		btnStartGame.setForeground(Color.WHITE);
		btnStartGame.setBackground(Color.BLACK);
		btnStartGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//kills the window when the player clicks Start Game.
				setVisible(false);
				dispose();
				new PacManWithUI().createController();
			}
		});
		btnStartGame.setBounds(133, 390, 109, 23);
		contentPane.add(btnStartGame);
		
		JRadioButton rdbtn1Ghost = new JRadioButton("1"); //One ghost in game.
		rdbtn1Ghost.setForeground(Color.WHITE);
		rdbtn1Ghost.setBackground(Color.BLACK);
		rdbtn1Ghost.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PacMan.setNumGhosts(1);
			}
		});
		buttonGroup_1.add(rdbtn1Ghost); //Ensures only one button can be picked for the ghosts.
		rdbtn1Ghost.setBounds(55, 253, 55, 23);
		contentPane.add(rdbtn1Ghost);
		
		JRadioButton rdbtn2Ghosts = new JRadioButton("2"); //Two ghosts in game.
		rdbtn2Ghosts.setForeground(Color.WHITE);
		rdbtn2Ghosts.setBackground(Color.BLACK);
		rdbtn2Ghosts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PacMan.setNumGhosts(2);
			}
		});
		buttonGroup_1.add(rdbtn2Ghosts); //Ensures only one button can be picked for the ghosts.
		rdbtn2Ghosts.setBounds(133, 253, 55, 23);
		contentPane.add(rdbtn2Ghosts);
		
		JRadioButton rdbtn3Ghosts = new JRadioButton("3"); //Three ghosts in the game.
		rdbtn3Ghosts.setForeground(Color.WHITE);
		rdbtn3Ghosts.setBackground(Color.BLACK);
		rdbtn3Ghosts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PacMan.setNumGhosts(3);
			}
		});
		buttonGroup_1.add(rdbtn3Ghosts); //Ensures only one button can be picked for the ghosts.
		rdbtn3Ghosts.setBounds(200, 253, 66, 23);
		contentPane.add(rdbtn3Ghosts);
		
		JRadioButton rdbtn4Ghosts = new JRadioButton("4"); //Four ghosts in the game.
		rdbtn4Ghosts.setForeground(Color.WHITE);
		rdbtn4Ghosts.setBackground(Color.BLACK);
		rdbtn4Ghosts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PacMan.setNumGhosts(4);
			}
		});
		buttonGroup_1.add(rdbtn4Ghosts); //Ensures only one button can be picked for the ghosts.
		rdbtn4Ghosts.setBounds(268, 253, 109, 23);
		contentPane.add(rdbtn4Ghosts);
		
		JLabel lblNumGhosts = new JLabel("Select Number of Ghosts"); //Tells the player what the buttons are for.
		lblNumGhosts.setForeground(Color.WHITE);
		lblNumGhosts.setBackground(Color.BLACK);
		lblNumGhosts.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblNumGhosts.setBounds(79, 192, 268, 54);
		contentPane.add(lblNumGhosts);
		
		JLabel lblDifficulty = new JLabel("Select Difficulty"); //Tells the player what they are selecting.
		lblDifficulty.setForeground(Color.WHITE);
		lblDifficulty.setBackground(Color.BLACK);
		lblDifficulty.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblDifficulty.setBounds(117, 293, 181, 29);
		contentPane.add(lblDifficulty);
		
		JRadioButton rdbtnEasy = new JRadioButton("Easy"); //Slow speed for ghosts and pacman.
		rdbtnEasy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Ghost.setGhostSpeed(15);
				Pac.setPacSpeed(5);
				Ghost.setDifficulty(1);
			}
		});
		rdbtnEasy.setForeground(Color.WHITE);
		rdbtnEasy.setBackground(Color.BLACK);
		buttonGroup.add(rdbtnEasy); 			//Ensures only one button can be picked for the Difficulty(speed).
		rdbtnEasy.setBounds(86, 329, 66, 23);
		contentPane.add(rdbtnEasy);
		
		JRadioButton rdbtnMedium = new JRadioButton("Medium"); //Normal speed for pacman and the ghosts.
		rdbtnMedium.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Ghost.setGhostSpeed(10);
				Pac.setPacSpeed(9);
				Ghost.setDifficulty(2);
			}
		});
		rdbtnMedium.setForeground(Color.WHITE);
		rdbtnMedium.setBackground(Color.BLACK);
		buttonGroup.add(rdbtnMedium);			//Ensures only one button can be picked for the Difficulty(speed).
		rdbtnMedium.setBounds(154, 329, 76, 23);
		contentPane.add(rdbtnMedium);
		
		JRadioButton rdbtnHard = new JRadioButton("Hard"); //Fast speed for the ghosts and pacman.
		rdbtnHard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Ghost.setGhostSpeed(7);
				Pac.setPacSpeed(7);
				Ghost.setDifficulty(3);
			}
		});
		rdbtnHard.setForeground(Color.WHITE);
		rdbtnHard.setBackground(Color.BLACK);
		buttonGroup.add(rdbtnHard);				//Ensures only one button can be picked for the Difficulty(speed).
		rdbtnHard.setBounds(243, 329, 55, 23);
		contentPane.add(rdbtnHard);
		
		JRadioButton rdbtn1Player = new JRadioButton("1 Player"); //One player in the game at a time.
		rdbtn1Player.setForeground(Color.WHITE);
		rdbtn1Player.setBackground(Color.BLACK);
		rdbtn1Player.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PacMan.setNumPlayers(1);
			}
		});
		buttonGroup_2.add(rdbtn1Player); //Ensure that player can not choose both one and two players.
		rdbtn1Player.setBounds(101, 121, 102, 23);
		contentPane.add(rdbtn1Player);
		
		JRadioButton rdbtn2Players = new JRadioButton("2 Players"); //Two players in the game.
		rdbtn2Players.setForeground(Color.WHITE);
		rdbtn2Players.setBackground(Color.BLACK);
		rdbtn2Players.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PacMan.setNumPlayers(2);
			}
		});
		buttonGroup_2.add(rdbtn2Players);			//Ensure that player can not choose both one and two players.
		rdbtn2Players.setBounds(219, 121, 109, 23);
		contentPane.add(rdbtn2Players);
		
		JLabel lblPlayerText = new JLabel("Select Number of Players"); //Tell the player what they are selecting.
		lblPlayerText.setForeground(Color.WHITE);
		lblPlayerText.setBackground(Color.BLACK);
		lblPlayerText.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblPlayerText.setBounds(67, 50, 268, 64);
		contentPane.add(lblPlayerText);
		
		JLabel lblInstrct1 = new JLabel("Player 1 uses arrow keys to move."); //Give them some instructions on how to control pacman 1.
		lblInstrct1.setForeground(Color.WHITE);
		lblInstrct1.setBackground(Color.BLACK);
		lblInstrct1.setBounds(117, 151, 197, 14);
		contentPane.add(lblInstrct1);
		
		JLabel lblInstruct2 = new JLabel("Player 2 uses WASD keys to move."); //Give them some instructions on how to control pacman 2.
		lblInstruct2.setForeground(Color.WHITE);
		lblInstruct2.setBackground(Color.BLACK);
		lblInstruct2.setBounds(117, 167, 197, 14);
		contentPane.add(lblInstruct2);
		
		JLabel lblMenuName = new JLabel("OPTIONS"); //The name of the menu.
		lblMenuName.setForeground(Color.WHITE);
		lblMenuName.setBackground(Color.BLACK);
		lblMenuName.setFont(new Font("Tahoma", Font.BOLD, 28));
		lblMenuName.setBounds(129, 11, 145, 46);
		contentPane.add(lblMenuName);
		
		JLabel lblPinkGhost = new JLabel("New label"); //Used to make an image of the bigger ghosts on the menu
		lblPinkGhost.setIcon(new ImageIcon(Options.class.getResource("/sim/app/pacman/images/pinyBig.png")));
		lblPinkGhost.setBounds(10, 349, 88, 64);
		contentPane.add(lblPinkGhost);
		
		JLabel lblOrangeGhost = new JLabel("New label");	//Used to make an image of the bigger ghosts on the menu
		lblOrangeGhost.setIcon(new ImageIcon(Options.class.getResource("/sim/app/pacman/images/clydeBig.png")));
		lblOrangeGhost.setBounds(288, 349, 88, 64);
		contentPane.add(lblOrangeGhost);
		
		JLabel lblCyanGhost = new JLabel("New label");	//Used to make an image of the bigger ghosts on the menu
		lblCyanGhost.setIcon(new ImageIcon(Options.class.getResource("/sim/app/pacman/images/inkyBig.png")));
		lblCyanGhost.setBounds(10, 11, 88, 64);
		contentPane.add(lblCyanGhost);
		
		JLabel lblRedGhost = new JLabel("New label");	//Used to make an image of the bigger ghosts on the menu
		lblRedGhost.setIcon(new ImageIcon(Options.class.getResource("/sim/app/pacman/images/blinkyBig.png")));
		lblRedGhost.setBounds(288, 9, 89, 64);
		contentPane.add(lblRedGhost);
		
		JRadioButton rdbtnOrangeRightEye = new JRadioButton("");
		rdbtnOrangeRightEye.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Ghost.orangeEyeRight(true);
			}
		});
		rdbtnOrangeRightEye.setBackground(Color.BLACK);
		rdbtnOrangeRightEye.setBounds(326, 363, 21, 23);
		contentPane.add(rdbtnOrangeRightEye);
		
		JRadioButton rdbtnNeverDie = new JRadioButton(""); //The second hidden button, in the center of the bottom left ghost.
		rdbtnNeverDie.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Pac.setNeverDie(true);
			}
		});
		rdbtnNeverDie.setBackground(Color.BLACK);
		rdbtnNeverDie.setBounds(39, 375, 21, 23);
		contentPane.add(rdbtnNeverDie);
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}
