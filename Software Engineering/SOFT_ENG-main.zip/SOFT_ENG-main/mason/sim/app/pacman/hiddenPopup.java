package sim.app.pacman;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JRadioButton;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ButtonGroup;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.AbstractAction;
import javax.swing.Action;
import java.awt.FlowLayout;


//This is the code for the hidden game mode popup. Being text alone it is all rather self-explanatory.
public class hiddenPopup extends JFrame {
	
	public static void showFrame() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					hiddenPopup frame = new hiddenPopup();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public static void showWindow() {
		showFrame();
	}
	
	public hiddenPopup() {
		getContentPane().setBackground(Color.BLACK);
		getContentPane().setForeground(Color.BLACK);
		getContentPane().setLayout(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 519, 275);
		
		
		JLabel lblYouHaveActivated = new JLabel("You have activated the secret gamemode, flashlight!");
		lblYouHaveActivated.setForeground(Color.WHITE);
		lblYouHaveActivated.setBounds(30, 11, 360, 17);
		lblYouHaveActivated.setFont(new Font("Tahoma", Font.BOLD, 14));
		getContentPane().add(lblYouHaveActivated);
		
		JLabel lblTheGameHas = new JLabel("The game has been paused to let you read this.");
		lblTheGameHas.setForeground(Color.WHITE);
		lblTheGameHas.setBounds(102, 39, 315, 14);
		getContentPane().add(lblTheGameHas);
		
		JLabel lblInstruct = new JLabel("Guide PacMan as normal using arrow keys, but wasd how controls a flashlight.");
		lblInstruct.setForeground(Color.WHITE);
		lblInstruct.setBounds(30, 69, 484, 34);
		getContentPane().add(lblInstruct);
		
		JLabel lblDetails = new JLabel("Ghosts in the flashlight's beam will be slowed, otherwise they will be very fast!");
		lblDetails.setBackground(Color.BLACK);
		lblDetails.setForeground(Color.WHITE);
		lblDetails.setBounds(30, 114, 463, 34);
		getContentPane().add(lblDetails);
		
		JButton btnNewButton = new JButton("OK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				dispose();
			}
		});
		btnNewButton.setBackground(Color.BLACK);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBounds(181, 159, 89, 23);
		getContentPane().add(btnNewButton);
	}
}
